const express = require('express');
const path = require('path');
const db = require('./db');

const app = express();
app.use(express.json());
// Serve static files from project root (keeps existing structure)
app.use(express.static(path.join(__dirname)));

// API: get full app state
app.get('/api/appdata', (req, res) => {
  try {
    const state = db.getState();
    res.json(state);
  } catch (err) {
    console.error('GET /api/appdata error', err);
    res.status(500).json({ error: 'DB error' });
  }
});

// API: overwrite app state
app.post('/api/appdata', (req, res) => {
  try {
    db.setState(req.body);
    res.json({ ok: true });
  } catch (err) {
    console.error('POST /api/appdata error', err);
    res.status(500).json({ error: 'DB error' });
  }
});

app.get('/api/health', (req, res) => {
  res.json({ ok: true, db: !!db });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
