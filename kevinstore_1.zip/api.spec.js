const { test, expect } = require('@playwright/test');

// Ensure TEST_BASE_URL points to the running server (default: http://localhost:3000)
const BASE = process.env.TEST_BASE_URL || 'http://localhost:3000';

test.describe('API persistence', () => {
  test('POST /api/appdata then GET returns the same state', async ({ request }) => {
    const sample = {
      clientes: [{ id: 't1', nombre: 'ApiTestClient' }],
      productos: [{ id: 'p1', nombre: 'Prod', precio: 9.99 }],
      ventas: [],
      cuentas: []
    };

    // POST to save
    const postResp = await request.post(`${BASE}/api/appdata`, { data: sample });
    expect(postResp.ok(), 'POST /api/appdata should succeed').toBeTruthy();

    // GET to retrieve
    const getResp = await request.get(`${BASE}/api/appdata`);
    expect(getResp.ok(), 'GET /api/appdata should succeed').toBeTruthy();
    const json = await getResp.json();

    expect(json).toBeTruthy();
    expect(json.clientes).toBeDefined();
    expect(Array.isArray(json.clientes)).toBeTruthy();
    expect(json.clientes[0].nombre).toBe('ApiTestClient');
    expect(json.productos[0].nombre).toBe('Prod');
  });
});
