const fs = require('fs');
const path = require('path');
const dbPath = path.join(__dirname, 'data', 'app.db');
const outDir = path.join(__dirname, 'data', 'backups');
if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
const ts = new Date().toISOString().replace(/[:.]/g, '-');
const dest = path.join(outDir, `app-${ts}.db`);

if (!fs.existsSync(dbPath)) {
  console.error('No se encontró la base de datos en', dbPath);
  process.exit(1);
}

fs.copyFileSync(dbPath, dest);
console.log('Backup creado en', dest);
