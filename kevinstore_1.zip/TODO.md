### Confirmaciones y seguridad

- Añadido un modal accesible de confirmación que se usa al eliminar un producto o un movimiento de cuenta (evita borrados accidentales). El modal es accesible por teclado (ESC cancela, Tab navega entre botones) y persiste el foco correctamente.

### Mejora del focus-trap

- He mejorado el focus-trap del modal para que sea robusto: ahora calcula automáticamente todos los elementos enfocables dentro del modal y cicla correctamente con Tab y Shift+Tab.
- Mientras el modal está abierto la página queda marcada como inert/`aria-hidden` para que lectores de pantalla y teclado no interactúen con el fondo. El foco se restaura al elemento previo al cerrar.
- Opciones de cierre: botón "Eliminar", botón "Cancelar", clic en overlay y tecla ESC.

# TODO: Improve CSS for Dynamism and Intuitiveness

- [x] Add more CSS custom properties for colors, spacing, and animations
- [x] Improve animations and transitions (e.g., fade-ins, slide-ins)
- [x] Add focus states for better accessibility
- [x] Enhance responsive design with more breakpoints
- [x] Add subtle effects like gradients and enhanced shadows
- [x] Organize CSS with better comments and structure

- [x] Integrate Google Fonts (Inter)
- [x] Add a persistent dark/light theme toggle (JS + localStorage)

## Cambios implementados

 
 Se añadió un resumen en vivo para ventas (subtotal por línea + total) y validación de stock antes de confirmar la venta.
 Se añadieron toasts (notificaciones) para acciones (agregar/editar/eliminar/registrar) y errores no intrusivos.
 Se incluyeron campos de búsqueda/filtrado para clientes y productos, con acciones rápidas "Limpiar".

## Cómo probar

1. Abrir `index.html` en un navegador (doble clic o servidor local).
2. Navegar por teclado (tab) y verificar que los campos y botones muestren `focus-visible`.
3. Cambiar el ancho de la ventana para confirmar que las secciones pasan de 2 columnas a 1 columna.
4. Registrar clientes/productos/ventas para ver que listas y paneles mantienen scroll y estilo.
5. Usar el botón "Tema" en la esquina superior para alternar claro/oscuro. La elección se guarda en el navegador.

### Qué probar ahora (funcionalidad mejorada)

• Ventas: crea una venta, agrega varios productos y ajusta cantidades — verás el resumen por línea con precio/subtotal y el monto total se calcula automáticamente. Si el stock es insuficiente la venta quedará deshabilitada hasta corregirlo.
• Notificaciones: acciones como agregar/actualizar/eliminar productos o clientes muestran toasts no intrusivos en la esquina inferior derecha.
• Búsqueda: usa los campos "Buscar clientes" y "Buscar productos" en sus secciones para filtrar la vista; el selector en formularios también se actualiza para mostrar resultados relevantes.

### Cambios recientes y cómo verificarlos (Cuentas / Clientes)

- La sección **Clientes** fue integrada dentro de **Cuentas**; la selección de cliente ya NO está disponible en el formulario de Ventas. Las ventas pueden registrarse sin cliente (se almacenan con `cliente: null`) y se muestran en el historial como `(Sin cliente)`.
- Ahora es posible ingresar un nombre de deudor manualmente en el formulario de Cuentas (`Nombre del cliente (opcional)`) sin que se agregue a la lista global de clientes; ese movimiento almacenará `clienteNombre` y se mostrará en Resumen/Historial.

Prueba rápida (manual):
1. Ir a **Cuentas** → Agregar cliente desde ahí (opcional).
2. Registrar un movimiento con **Nombre del cliente (opcional)** rellenado con un nombre que NO exista en la lista; guardar. Verificar en **Resumen** y **Historial** que aparece ese nombre, y que no se agregó un nuevo cliente en **Clientes**.
3. Ir a **Ventas** → registrar venta sin seleccionar cliente (usar producto/cantidad/método). Verificar en Historial que el cliente sale como `(Sin cliente)`.
4. Eliminar un movimiento desde Resumen y usar "Deshacer" en el toast para verificar restauración.

### Nuevas mejoras implementadas

- Deshacer (undo) para acciones destructivas: ahora al eliminar clientes, productos o movimientos verás una notificación con botón "Deshacer" que restaura el estado anterior si pulsas dentro del tiempo de espera.
- Accesibilidad/teclado: las filas de cliente y producto son enfocables (tab) y puedes usar Enter o Space para seleccionar rápidamente un cliente o navegar la lista.
- Empty-states consistentes: los paneles vacíos ahora muestran un mensaje y un icono con estilo consistente para mejorar la lectura y jerarquía visual.

### Pasos finales de comprobación (recomendados)

1. Verificar el flujo de eliminación → ver el toast con "Deshacer" y probar restaureción.
2. Revisar navegación por teclado en las listas: Tab hasta una fila y presionar Enter para seleccionar.
3. Probar en móvil y Safari (especialmente backdrop-filter y comportamiento de animaciones) para confirmar compatibilidad.
4. Revisar contraste y tamaños de hit-area para cumplir WCAG AA como objetivo (color contrast y foco visible).

---

## Persistencia en servidor (SQLite) ✅

He añadido una opción de persistencia en servidor usando SQLite. Cambios importantes:

- `db.js` (nuevo): inicializa `data/app.db` y expone `getState()` y `setState(obj)`.
- `server.js`: ahora usa Express y expone los endpoints `GET /api/appdata` y `POST /api/appdata`.
- `codigo.js`: `loadAppData()` y `saveAppData()` ahora intentan sincronizar con el servidor; si falla, hacen fallback a `localStorage`.
- `backup-db.js`: script para crear backups de la DB en `data/backups`.
- `package.json`: scripts `start`, `dev` y `backup-db` y dependencias sugeridas.

Instrucciones rápidas:

1. Instala dependencias: `npm install` (en la raíz del proyecto).
2. Inicia en desarrollo: `npm run dev` (recomendado instalar `nodemon` global o usar `npm run dev`).
3. Ejecuta backup: `npm run backup-db`.

Notas:
- Se mantiene `localStorage` como fallback para uso offline.
- Para producción recomiendo migrar a PostgreSQL o a una instancia DB gestionada si habrá múltiples usuarios concurrentes.


### Pruebas automáticas añadidas

- Se añadieron tests básicos de integración con Playwright (carpeta `tests/`) para validar: agregar cliente, seleccionar cliente, borrar y deshacer desde el toast. Además **se añadió `api.spec.js`** para validar los endpoints `POST /api/appdata` y `GET /api/appdata` (persistencia en servidor).
- Para ejecutar las pruebas API: levanta el servidor Express en http://localhost:3000 con `npm start`, instala dependencias con `npm install`, y ejecuta `npm run test:api`. Para ejecutar todos los tests Playwright: `npm run test:playwright`.
- Nota: si usas otra URL o puerto, exporta `TEST_BASE_URL` antes de ejecutar (por ejemplo `TEST_BASE_URL=http://localhost:3000 npx playwright test api.spec.js`).

Si quieres, puedo añadir: confirmación modal antes de borrar (por ejemplo eliminar producto/movimiento), modo oscuro avanzado con conmutador persistente, o optimizar la accesibilidad para cumplir WCAG AA/AAA.
