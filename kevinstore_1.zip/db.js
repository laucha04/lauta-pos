const path = require('path');
const fs = require('fs');

const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
const dbPath = path.join(dataDir, 'app.db');

let usingSqlite = false;
let db;
try {
  const Database = require('better-sqlite3');
  db = new Database(dbPath);
  // create tables
  db.exec(`
    CREATE TABLE IF NOT EXISTS app_state (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      content TEXT NOT NULL,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    INSERT OR IGNORE INTO app_state(id, content) VALUES (1, '{}');

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS user_state (
      user_id INTEGER PRIMARY KEY,
      content TEXT NOT NULL,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
  `);
  usingSqlite = true;
} catch (err) {
  console.warn('better-sqlite3 not available; falling back to file-based storage in data/flatdb.json', err);
}

if (usingSqlite) {
  function getState() {
    const row = db.prepare('SELECT content FROM app_state WHERE id = 1').get();
    try { return JSON.parse(row.content || '{}'); } catch (e) { return {}; }
  }
  function setState(obj) {
    const json = JSON.stringify(obj || {});
    const stmt = db.prepare('UPDATE app_state SET content = ?, updated_at = CURRENT_TIMESTAMP WHERE id = 1');
    return stmt.run(json);
  }

  function createUser(username, passwordHash) {
    const stmt = db.prepare('INSERT INTO users (username, password_hash) VALUES (?, ?)');
    return stmt.run(username, passwordHash);
  }

  function getUserByUsername(username) {
    return db.prepare('SELECT id, username, password_hash, created_at FROM users WHERE username = ?').get(username);
  }

  function getUserById(id) {
    return db.prepare('SELECT id, username, created_at FROM users WHERE id = ?').get(id);
  }

  function getUserState(userId) {
    const row = db.prepare('SELECT content, updated_at FROM user_state WHERE user_id = ?').get(userId);
    if (!row) return { content: {}, updated_at: null };
    try { return { content: JSON.parse(row.content || '{}'), updated_at: row.updated_at }; } catch (e) { return { content: {}, updated_at: row.updated_at } }
  }

  function setUserState(userId, obj) {
    const json = JSON.stringify(obj || {});
    const exists = db.prepare('SELECT 1 FROM user_state WHERE user_id = ?').get(userId);
    if (exists) {
      return db.prepare('UPDATE user_state SET content = ?, updated_at = CURRENT_TIMESTAMP WHERE user_id = ?').run(json, userId);
    } else {
      return db.prepare('INSERT INTO user_state(user_id, content) VALUES (?, ?)').run(userId, json);
    }
  }

  module.exports = { getState, setState, createUser, getUserByUsername, getUserById, getUserState, setUserState, path: dbPath };
} else {
  const flatPath = path.join(dataDir, 'flatdb.json');
  let flat = { nextUserId: 1, users: [], app_state: {}, user_state: {} };
  try {
    if (fs.existsSync(flatPath)) flat = JSON.parse(fs.readFileSync(flatPath, 'utf8')) || flat;
  } catch (e) { console.warn('Error reading flatdb.json', e); }

  function saveFlat() { try { fs.writeFileSync(flatPath, JSON.stringify(flat, null, 2), 'utf8'); } catch (e) { console.error('Error saving flatdb.json', e); } }

  function getState() { return flat.app_state || {}; }
  function setState(obj) { flat.app_state = obj || {}; saveFlat(); return { changes: true }; }

  function createUser(username, passwordHash) {
    const exists = flat.users.find(u => u.username === username);
    if (exists) throw new Error('username taken');
    const id = flat.nextUserId++;
    const user = { id, username, password_hash: passwordHash, created_at: new Date().toISOString() };
    flat.users.push(user); saveFlat(); return { lastInsertRowid: id };
  }

  function getUserByUsername(username) {
    return flat.users.find(u => u.username === username) || null;
  }

  function getUserById(id) { return flat.users.find(u => u.id === id) || null; }

  function getUserState(userId) {
    const row = flat.user_state[userId];
    if (!row) return { content: {}, updated_at: null };
    return { content: row.content || {}, updated_at: row.updated_at || null };
  }

  function setUserState(userId, obj) {
    flat.user_state[userId] = { content: obj || {}, updated_at: new Date().toISOString() };
    saveFlat();
    return { ok: true };
  }

  module.exports = { getState, setState, createUser, getUserByUsername, getUserById, getUserState, setUserState, path: flatPath };
}
