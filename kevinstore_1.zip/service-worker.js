const CACHE_NAME = 'lauta-app-v1';
const APP_SHELL = [
  '/',
  '/index.html',
  '/styles.css',
  '/codigo.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(
      keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
    )).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  // Network-first for navigations so the app shell can update
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req).then((res) => {
        // cache the latest index.html
        const resClone = res.clone();
        caches.open(CACHE_NAME).then(cache => cache.put('/index.html', resClone));
        return res;
      }).catch(() => caches.match('/index.html'))
    );
    return;
  }

  // Cache-first for other requests (static assets)
  event.respondWith(
    caches.match(req).then((cached) => cached || fetch(req).then((res) => {
      try {
        if (res && res.status === 200) {
          const resClone = res.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(req, resClone));
        }
      } catch (e) {
        // ignore caching errors
      }
      return res;
    }).catch(() => caches.match(req)))
  );
});
