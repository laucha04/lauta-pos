const express = require('express');
const path = require('path');
const db = require('./db');

const app = express();
app.use(express.json());
// Serve static files from project root (keeps existing structure)
app.use(express.static(path.join(__dirname)));

// API: get full app state (legacy, global single-app state)
app.get('/api/appdata', (req, res) => {
  try {
    const state = db.getState();
    res.json(state);
  } catch (err) {
    console.error('GET /api/appdata error', err);
    res.status(500).json({ error: 'DB error' });
  }
});

// API: overwrite app state (legacy)
app.post('/api/appdata', (req, res) => {
  try {
    db.setState(req.body);
    res.json({ ok: true });
  } catch (err) {
    console.error('POST /api/appdata error', err);
    res.status(500).json({ error: 'DB error' });
  }
});

// --- Authentication & per-user state endpoints ---
let bcrypt, jwt;
let AUTH_AVAILABLE = true;
try {
  bcrypt = require('bcrypt');
  jwt = require('jsonwebtoken');
} catch (err) {
  AUTH_AVAILABLE = false;
  console.warn('Auth modules bcrypt/jsonwebtoken are not available. Install dependencies with `npm install` to enable auth endpoints.', err);
}
const JWT_SECRET = process.env.JWT_SECRET || 'change_this_to_secure_secret';
const JWT_EXPIRES_IN = '7d';

// Register user
app.post('/api/register', async (req, res) => {
  if (!AUTH_AVAILABLE) return res.status(503).json({ error: 'auth not available on server (missing deps)' });
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'username and password required' });
  try {
    const existing = db.getUserByUsername(username);
    if (existing) return res.status(409).json({ error: 'username taken' });
    const hash = await bcrypt.hash(password, 10);
    const info = db.createUser(username, hash);
    res.json({ ok: true, userId: info.lastInsertRowid });
  } catch (err) {
    console.error('POST /api/register error', err);
    res.status(500).json({ error: 'DB error' });
  }
});

// Login
app.post('/api/login', async (req, res) => {
  if (!AUTH_AVAILABLE) return res.status(503).json({ error: 'auth not available on server (missing deps)' });
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ error: 'username and password required' });
  try {
    const user = db.getUserByUsername(username);
    if (!user) return res.status(401).json({ error: 'invalid credentials' });
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'invalid credentials' });
    const token = jwt.sign({ sub: user.id, username: user.username }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });
    res.json({ ok: true, token });
  } catch (err) {
    console.error('POST /api/login error', err);
    res.status(500).json({ error: 'Server error' });
  }
});

function authenticateToken(req, res, next) {
  if (!AUTH_AVAILABLE) return res.status(503).json({ error: 'auth not available on server (missing deps)' });
  const auth = req.headers && req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return res.status(401).json({ error: 'missing token' });
  const token = auth.split(' ')[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = { id: payload.sub, username: payload.username };
    next();
  } catch (err) {
    return res.status(401).json({ error: 'invalid token' });
  }
}

// Per-user state retrieval
app.get('/api/user/appdata', authenticateToken, (req, res) => {
  try {
    const row = db.getUserState(req.user.id);
    res.json({ ok: true, data: row.content || {}, updated_at: row.updated_at || null });
  } catch (err) {
    console.error('GET /api/user/appdata error', err);
    res.status(500).json({ error: 'DB error' });
  }
});

// Per-user state save (overwrites user's state)
app.post('/api/user/appdata', authenticateToken, (req, res) => {
  try {
    const content = req.body || {};
    db.setUserState(req.user.id, content);
    res.json({ ok: true });
  } catch (err) {
    console.error('POST /api/user/appdata error', err);
    res.status(500).json({ error: 'DB error' });
  }
});

app.get('/api/health', (req, res) => {
  res.json({ ok: true, db: !!db });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
