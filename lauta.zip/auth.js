/* ========== MÓDULO DE AUTENTICACIÓN ========== */

// Estado de autenticación global
let currentUser = null;
let authToken = null;

// Cargar estado de autenticación al iniciar
function initializeAuth() {
  const stored = localStorage.getItem('authToken');
  const userData = localStorage.getItem('userData');
  
  if (stored && userData) {
    try {
      authToken = stored;
      currentUser = JSON.parse(userData);
      // Validar token con servidor (opcional)
      validateTokenWithServer();
      // Cargar datos del usuario
      loadAppData();
      hideAuthModal();
      return true;
    } catch (e) {
      console.error('Error al restaurar sesión:', e);
      clearAuthSession();
      showAuthModal();
    }
  } else {
    // Si no hay sesión, mostrar modal de login
    showAuthModal();
  }
  return false;
}

// Función para reinicializar todos los event listeners después del login
function reinitializeAppListeners() {
  try {
    // Esperar a que el DOM esté completamente renderizado
    setTimeout(() => {
      if (typeof initializeEventListeners === 'function') {
        initializeEventListeners();
        console.log('✓ Event listeners re-inicializados después del login');
      } else {
        console.warn('initializeEventListeners function not found in codigo.js');
      }
    }, 100);
  } catch (err) {
    console.warn('Error reinicializando listeners:', err);
  }
}

// Mostrar modal de autenticación
function showAuthModal() {
  const modal = document.getElementById('auth-modal');
  const appContainer = document.getElementById('main-app-container');
  if (modal) {
    modal.setAttribute('aria-hidden', 'false');
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  }
  if (appContainer) {
    appContainer.style.display = 'none';
  }
}

// Ocultar modal de autenticación
function hideAuthModal() {
  const modal = document.getElementById('auth-modal');
  const appContainer = document.getElementById('main-app-container');
  if (modal) {
    modal.setAttribute('aria-hidden', 'true');
    modal.style.display = 'none';
    document.body.style.overflow = 'auto';
  }
  if (appContainer) {
    appContainer.style.display = 'flex';
  }
  updateUserDisplay();
  
  // Reinicializar listeners después de mostrar el contenido
  reinitializeAppListeners();
}

// Actualizar visualización del usuario en el header
function updateUserDisplay() {
  const userInfo = document.getElementById('auth-user-info');
  const userDisplay = document.getElementById('auth-user-display');
  
  if (currentUser && userInfo && userDisplay) {
    userInfo.style.display = 'flex';
    userDisplay.textContent = currentUser.usuario || currentUser.email || 'Usuario';
  } else if (userInfo) {
    userInfo.style.display = 'none';
  }
}

// Validar token con servidor
async function validateTokenWithServer() {
  try {
    const response = await fetch('/api/auth/validate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${authToken}`
      }
    });
    
    if (!response.ok) {
      clearAuthSession();
      showAuthModal();
      return false;
    }
    
    return true;
  } catch (err) {
    console.error('Error validando token:', err);
    // Continuar sin validación si el servidor no responde
    return true;
  }
}

// Limpiar sesión
function clearAuthSession() {
  currentUser = null;
  authToken = null;
  localStorage.removeItem('authToken');
  localStorage.removeItem('userData');
  localStorage.removeItem('appData');
}

// FUNCIONES DE FORMULARIO

// Manejar toggle entre login y registro
document.addEventListener('DOMContentLoaded', () => {
  const toggleToRegister = document.getElementById('toggle-to-register');
  const toggleToLogin = document.getElementById('toggle-to-login');
  const loginForm = document.getElementById('auth-login-form');
  const registerForm = document.getElementById('auth-register-form');
  
  if (toggleToRegister) {
    toggleToRegister.addEventListener('click', (e) => {
      e.preventDefault();
      loginForm.classList.remove('auth-form-active');
      registerForm.classList.add('auth-form-active');
    });
  }
  
  if (toggleToLogin) {
    toggleToLogin.addEventListener('click', (e) => {
      e.preventDefault();
      registerForm.classList.remove('auth-form-active');
      loginForm.classList.add('auth-form-active');
    });
  }

  // Manejar envío del formulario de login
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      handleLogin();
    });
  }

  // Manejar envío del formulario de registro
  if (registerForm) {
    registerForm.addEventListener('submit', (e) => {
      e.preventDefault();
      handleRegister();
    });
  }

  // Manejar logout
  const btnLogout = document.getElementById('btn-logout');
  if (btnLogout) {
    btnLogout.addEventListener('click', handleLogout);
  }
});

// Función de Login
async function handleLogin() {
  const usuario = document.getElementById('login-usuario').value.trim();
  const password = document.getElementById('login-password').value;
  const errorDiv = document.getElementById('login-error');
  
  // Validación básica
  if (!usuario || !password) {
    showAuthError('login-error', 'Por favor completa todos los campos');
    return;
  }
  
  try {
    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ usuario, password })
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      showAuthError('login-error', data.error || 'Error en el inicio de sesión');
      return;
    }
    
    // Guardar token y datos de usuario
    authToken = data.token;
    currentUser = data.user;
    
    localStorage.setItem('authToken', authToken);
    localStorage.setItem('userData', JSON.stringify(currentUser));
    
    showToast(`¡Bienvenido ${currentUser.usuario}!`, 'success');
    hideAuthModal();
    
    // Cargar datos del usuario
    loadAppData();
  } catch (err) {
    console.error('Error en login:', err);
    showAuthError('login-error', 'Error de conexión. Intenta nuevamente.');
  }
}

// Función de Registro
async function handleRegister() {
  const usuario = document.getElementById('register-usuario').value.trim();
  const email = document.getElementById('register-email').value.trim();
  const password = document.getElementById('register-password').value;
  const passwordConfirm = document.getElementById('register-password-confirm').value;
  const errorDiv = document.getElementById('register-error');
  
  // Validaciones
  if (!usuario || !email || !password || !passwordConfirm) {
    showAuthError('register-error', 'Por favor completa todos los campos');
    return;
  }
  
  if (usuario.length < 3 || usuario.length > 20) {
    showAuthError('register-error', 'El usuario debe tener entre 3 y 20 caracteres');
    return;
  }
  
  if (!/^[a-zA-Z0-9_-]+$/.test(usuario)) {
    showAuthError('register-error', 'El usuario solo puede contener letras, números, guiones y guiones bajos');
    return;
  }
  
  if (password.length < 8) {
    showAuthError('register-error', 'La contraseña debe tener al menos 8 caracteres');
    return;
  }
  
  if (password !== passwordConfirm) {
    showAuthError('register-error', 'Las contraseñas no coinciden');
    return;
  }
  
  // Validar email básico
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    showAuthError('register-error', 'Email inválido');
    return;
  }
  
  try {
    const response = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ usuario, email, password })
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      showAuthError('register-error', data.error || 'Error al registrarse');
      return;
    }
    
    showToast('Cuenta creada exitosamente. Inicia sesión ahora.', 'success');
    
    // Cambiar a formulario de login
    document.getElementById('auth-register-form').classList.remove('auth-form-active');
    document.getElementById('auth-login-form').classList.add('auth-form-active');
    
    // Prellenar usuario
    document.getElementById('login-usuario').value = usuario;
    document.getElementById('login-password').value = '';
    document.getElementById('login-password').focus();
  } catch (err) {
    console.error('Error en registro:', err);
    showAuthError('register-error', 'Error de conexión. Intenta nuevamente.');
  }
}

// Función de Logout
async function handleLogout() {
  if (!confirm('¿Estás seguro de que deseas cerrar sesión?')) {
    return;
  }
  
  try {
    // Notificar al servidor (opcional)
    if (authToken) {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        }
      }).catch(() => {});
    }
  } catch (err) {
    console.error('Error en logout:', err);
  }
  
  // Limpiar sesión local
  clearAuthSession();
  
  // Limpiar datos de la app
  clientes = [];
  productos = [];
  ventas = [];
  cuentas = [];
  cajaMovimientos = [];
  cajaBilletes = {};
  cajaBilletesRegistro = [];
  DENOMINACIONES.forEach(d => cajaBilletes[d] = 0);
  
  // Limpiar UI
  actualizarListaClientes();
  actualizarListaProductosYStock();
  actualizarListaVentas();
  actualizarResumenCuentas();
  actualizarMovimientosCaja();
  
  showToast('Sesión cerrada', 'success');
  showAuthModal();
}

// Mostrar error en formulario
function showAuthError(elementId, message) {
  const errorDiv = document.getElementById(elementId);
  if (errorDiv) {
    errorDiv.textContent = message;
    errorDiv.style.display = 'block';
    setTimeout(() => {
      errorDiv.style.display = 'none';
    }, 5000);
  }
}

// Reemplazar Referencias Globales
// Las funciones saveAppData y loadAppData en codigo.js ya manejan autenticación automáticamente
// Así que ya no es necesario parchear - funcionan nativamente con auth
function patchAuthFunctions() {
  // Ya no es necesario parchear, las funciones en codigo.js ya chequean authToken
  console.log('Sistema de autenticación integrado correctamente');
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
  // Pequeño retraso para asegurar que se cargan las funciones globales
  setTimeout(() => {
    patchAuthFunctions();
    initializeAuth();
  }, 100);
});
